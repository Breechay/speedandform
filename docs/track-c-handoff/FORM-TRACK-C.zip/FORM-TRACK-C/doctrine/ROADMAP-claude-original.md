# FORM · ROADMAP

The standing ledger. Every open thread lives here, already decided, in order.

**How to use it.** Work top-down within a track. Do not start a track above its gate.
When you finish an item, change its status in place and add the date — do not delete it.
If you disagree with a decision here, say so before building; do not silently redesign.

`[ ]` open · `[~]` in progress · `[x]` done · `[—]` cut, kept for the record

Last updated: Aug 19 2026.

---

## GATE 0 — nothing below this line matters until these ship

- `[ ]` **A1 · Commit and push the FORM-iOS working tree.** Branch `cursor/the-plan-binding-93e5`. The tree is still local; the existing archive predates the programming, cache and footer fixes and must not be reused.
- `[ ]` **A2 · Fresh archive from that commit.** Version 38 / Build 5, device family `1,2`. Upload.
- `[ ]` **A3 · Paste the App Store metadata.** Subtitle, promo, description and What's New are written in `docs/claude-handoff/APP-STORE-COPY.md`. Metadata edits are free until the build goes to review.
- `[ ]` **A4 · Warn the beta athletes before 38 lands.** Everyone opens at W1 / WEEK 1 while their race clock is unchanged. One line: the week counter starts over because the app did; your race clock and your training did not. Without this it reads as a reset.
- `[ ]` **A5 · Confirm the intake send path end to end.** Submit the form from a phone, find the FormSubmit confirmation email (check spam), click it, confirm a real submission arrives. Until that click, nothing forwards.
- `[ ]` **A6 · Merge `/mockupc` to `/`.** The twin carries the race line, the W1 tab, the placard and the tell. Every doc now describes a page that only exists at the twin.
- `[ ]` **A7 · Send the link to ten people.** This is the actual next information. Distribution is the bottleneck, not product quality.

---

## TRACK B — the website

- `[x]` B1 · Plate 03 THE INSTRUMENT: dial, mask, week marks, scroll assembly. *Aug 19*
- `[x]` B2 · The race line under the disc. *Aug 19*
- `[x]` B3 · The W1 margin tab, the placard, the tell. *Aug 19*
- `[x]` B4 · Intake: success gating, mailto fallback, receipt-scale review, text-size-adjust. *Aug 19*
- `[ ]` **B5 · The dragon is not there yet.** It reads as a shape in the corner, not as weather. Next lever is the crop and the opacity, not the size. It never becomes anatomy.
- `[ ]` **B6 · Thin lines are on notice.** Brice does not like the hairline rules — the ruler above the week row and the race line on the Week Print. Decision: **a hairline must carry meaning at a glance or it is noise.** The race line stays on the plate, where the disc labels it (`BUILDS HOLD`). It comes off any surface where it has to be guessed at. Where a divider is only separating things, use space instead.
- `[ ]` B7 · Record the plate, portrait, one full cycle, for Instagram — after 38 is approved.
- `[ ]` B8 · Decide whether `/notes` should be reachable. It is currently orphaned by design. If it should be linked, the place is the done screen.

---

## TRACK C — Today becomes the instrument

Gate: A1–A7 done. The site is ahead of the app; do not lose it by rushing the port.

The governing idea, from Brice: **the plan now lives in the placard, so Today can hold less.**
Today shows today. The week is atmosphere. The plan is behind the tab.

- `[ ]` **C1 · The wordmark.** Adopt the site's FORM lockup in the app — letterspaced serif caps. It is the single strongest recognition asset either surface has.
- `[ ]` **C2 · The typography rule, not the font.** Fraunces carries the **authored** layer: session names, chapter and week-print headlines, the Read line. SF keeps the **measured** layer: paces, splits, durations, every figure, tabular numerals. Never set a pace in Fraunces. Ship a subset static instance bundled in-app, not a variable font over the network. *(The serif inside the site's sun and the serif in the headline are the same family — that is why it feels coherent.)*
- `[ ]` **C3 · Kill the header.** `FORM / Tuesday / the eighteenth of august` is three lines announcing what the disc already says. Keep the wordmark. The day name moves into the disc, where the site already puts it.
- `[ ]` **C4 · The week recedes.** Not all seven days need to be legible. Match the site: static blur, low opacity, the outer days clipping off the edges. The week is where you are, not what you read.
- `[ ]` **C5 · FILE SESSION becomes a real affordance.** Adopt the site's boxed CTA. A hairline-underlined word is not a button; the primary action of the screen should look like one.
- `[ ]` **C6 · The placard replaces the brown plan sheet.** Brice's call and mine: the brown does not photograph as desirable and the site's ivory panel is better. The plan opens from the margin tab, over the instrument, and the instrument steps aside rather than being covered.
- `[ ]` **C7 · Editing moves into the placard, concealed.** The placard reads as a plan at rest. `Edit` reveals the controls — days per week, long-run day, can't-run days, race and goal. No separate plan-editing surface.
- `[ ]` **C8 · Audit the two-language problem.** FORM draws the four movements twice — the race rings and the struck registration mark. One concept, one language. My call: keep the mark, delete the rings.

---

## TRACK D — the voice audit

Trigger: the plain-voice law. **A line says what happened in the words a coach would use standing next to the athlete. Nothing to decipher, no internal vocabulary.**

Found so far, all athlete-facing:

- `[x]` **D1 · "Nothing was classified this block."** → *Nothing was recorded this block.* *Aug 19*
- `[x]` **D2 · "You did the work, but this condition can't judge it. It needs a different kind."** → *You did the work. This kind of session can't tell me what I need to know.* *Aug 19*
- `[x]` **D3 · "Held, but too few sessions to move a number that governs eight weeks."** → *You held it, but not enough times for me to change your paces.* *Aug 19*
- `[x]` **D4 · "Program Director checked this against your goal and week structure."** → cut. Athlete-facing *Program Director* titles were renamed to *Plan changes* / *Your plan*. *Aug 19*
- `[x]` **D5 · "band"** stays in the model; the athlete-facing phrase is **your paces**. Direct verdicts use *planned pace* when that reads more naturally. *Aug 19*
- `[x]` **D6 · VoiceOver strings** now say what the sighted surface shows: *filed*, *not filed*, *rest* / *no session*. *Aug 19*
- `[x]` **D7 · Sweep the rest.** Athlete-facing schema vocabulary was replaced with the run, action or result it described; the Read guard now rejects that vocabulary before new copy ships. *Aug 19*

---

## TRACK E — the world with rules

Gate: Track C landed. Atmosphere on top of a surface still being rebuilt is wasted work.

- `[ ]` **E1 · Wire the chapter close.** It is written and unreachable — four full-screen takeovers in Brice's voice, firing when a block binds, with zero production call sites. This is the highest-leverage item in the whole brainstorm and it is a wiring problem, not a design problem.
- `[ ]` **E2 · The Week Print.** Mock exists (`week-print.html`). It prints what happened including a light week. Archive, never recap. No totals framed as achievement, no comparison to last week.
- `[ ]` **E3 · Marks as building material.** The mark vocabulary — easy, intervals, speed, long, rest, threshold — becomes the shared material across the dial, the print, the chapter pages and the Record. A type gets a mark in both places or in neither.
- `[ ]` **E4 · Motion grammar.** 30–90s, 2–6px, the `weatherDrift` family. The thought should be *was that there before*, never *there it goes*.
- `[ ]` **E5 · One tactile signature.** A soft haptic on filing. Silent.
- `[ ]` **E6 · Never show the whole dragon.** Fragments, across surfaces, over years. Never a mascot, never a reward.

---

## DECIDED — do not re-litigate

- **Time makes the marks, not merit.** A day run and a day not run both leave a mark; only the character differs. Nothing may read as a score, a streak, or a completion.
- **Clouds are not weather data and not a plan tier.** Atmosphere never has to earn its existence with a number.
- **No sound.** The haptic is the signature. People run with headphones.
- **Depth by focus, not by blur.** The instrument dissolves at its own edges; the copy sits on clean paper in front of it.
- **The outgoing must be gone before the incoming arrives** in any cross-fade.
- **Opacity may transition; filter never does.**
- **Show, don't tell.** No legends, no keys, no paragraph explaining the instrument.
- **Payment is Zelle, arranged in the reply.** No cart, no Stripe, no checkout.
- **Phase changes may alter air, saturation and crop. They may never read as approval or warning.**

---

## OPEN — needs Brice, not an agent

- `[ ]` Confirm the mark vocabulary against the real dial: do Intervals and Speed actually differ in the app, or did the site invent a distinction?
- `[ ]` Whether `/notes` becomes reachable (B8).
- `[ ]` The Observation Close amendment: for a named-athlete note, is the Close "the sensation to go find, and what produces it" rather than "the decision it changes"?
