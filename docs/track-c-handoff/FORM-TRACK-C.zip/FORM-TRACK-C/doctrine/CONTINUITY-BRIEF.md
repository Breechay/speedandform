# FORM — Continuity Brainstorm
### A working brief from Claude, as partner — not a spec, not a ruling

Brice — this is my honest take, reacting to Codex's memo, reacting to what's actually sitting in
the repo (a lot more than either of us assumed), and reacting to the specific things you flagged:
the rings, the flow start-to-close, the chapter close we apparently already designed and never
wired. I read the code before I wrote any of this. Where I disagree with Codex I say so and why.
Where I agree I try to say what it actually costs to build, in FORM's own vocabulary, not
Codex's. Nothing here is a ruling — it's material for the conversation. `mockups/continuity_pass_01.html`
is the visual half of this document; open it in a browser, it's not a slide deck, it's meant to be
scrolled and judged the way you'd judge the app.

---

## 1. The one-sentence thesis

**FORM already built the thing Codex is asking for. It just never turned it on.**

Codex's memo is good — genuinely good, not flattery. The core move ("the instrument is exact, the
world around it is alive") is the right shape of idea. But the specific vehicle it reaches for — a
mythological dragon glimpsed in fragments, borrowed from Vietnamese art-book references — isn't
FORM's material, and it's not necessary. When I went looking for where an idea like that would
have to live in the actual codebase, I found `FORMMovementChapterPage.swift`: four full-screen
takeovers across a Half campaign, in your own authored voice — *"first honest miles," "the long
middle," "when it gets specific," "carrying it in"* — that fire only when a training block
actually binds, never on a calendar boundary, and explain nothing. That *is* "never show the whole
dragon." It's just made of language and a numeral instead of a creature, and it's finished, sitting
in `Packages/FORMMovementKit/Sources/FORMMovementKit/`, reachable today only through a `#if DEBUG`
rail. Zero production call sites. Nobody has ever seen it except in a debug build.

So before this becomes a conversation about new visual language, it should be a conversation about
finishing the sentence you already wrote.

---

## 2. What I'd take from Codex's memo, and what I'd leave

**Take, mostly as-is:**
- *"The instrument is exact, the world around it is alive."* Correct framing. The Sun/plate stays
  locked (it already is — see §6). Atmosphere belongs at the seams, not inside the instrument.
- *"Visual seasons"* — the training phase changing what surrounds the instrument. FORM already has
  the authority for this (`FORMWeekChapterAuthority`, phase-indexed), it's just never been asked to
  drive anything visual beyond the chapter page itself.
- *"Motion is noticing, not watching."* This is the single best idea in the memo and it costs
  almost nothing to adopt as a stated rule. See §5.
- *"Make finishing work change the picture."* Yes — but tie the change to **calendar/campaign
  progress**, not to volume or compliance. See the gamification note below; this is where the memo
  needs a correction, not a rejection.
- *The Week Print (idea #5).* The best concrete proposal in the memo. See §4.

**Leave, or replace:**
- **The dragon itself.** Two problems, not one. First, it's off-brand: the paper-material-pass
  memory (`form-paper-material-pass`) explicitly and permanently excludes "ornament" and
  "decorative pseudo-technical metadata" from FORM's surfaces, for a stated reason — *"FORM is
  technical because the instrument is real."* A creature, however fragmentary, is illustration.
  Second, and more important: **a thing that becomes more visible as the athlete trains more is a
  reward schedule, full stop — even without a number attached to it.** Codex's memo says outright
  "that's different from gamification," but structurally it isn't; it's just a slower, more
  tasteful drip. `form-legibility-and-dial-doctrine` already drew this exact line: FORM's objection
  was never to rings or marks or a number, it's to *motivational pressure that outruns semantic
  truth*. A dragon that grows because you ran more is semantically empty — the athlete didn't earn
  dragon-scales, they earned a filed threshold session. If atmosphere is going to change, it should
  change because of something FORM can actually say happened (a phase turned over, a block closed,
  a week filed) — never because a volume counter crossed a threshold. That's not a stylistic
  preference, it's the same law that killed streaks and XP. **Reveal on calendar/campaign truth,
  never on compliance.** The chapter close already does this correctly; whatever else gets built
  should copy its rule, not the dragon's.
- **A borrowed visual motif from a specific external reference (the Vietnamese art books).** Take
  the *lesson* (density can spike, then go bare; scale and rhythm can do the work typography
  usually does) without taking the *material*. FORM's own structure-grammar prototype
  (`docs/design/structure-grammar/`) is already reaching for the same instinct — ticks and marks
  that "teach themselves through repetition, no legend" — from FORM's own vocabulary. That's the
  system to extend, not a new mythology laid on top of it.

---

## 3. The rings — my actual recommendation

You said you don't love how they look. Having read `FORMRaceRingView.swift`, I don't think you're
wrong, and I don't think the fix is a paint job.

**What's shipped:** one circle, cut into four *unequal* arcs (Start/Settle/Hold/Finish, weighted by
race-share — Half is 15/40/25/20), each arc has a track (dim) and a fill (proportional to evidence
filed), plus a label + small seal glyph floating outside each arc at its midpoint angle. It's
reached only by over-rotating past the dial's terminal tooth — an Easter egg gesture, not an
integrated surface — and it's explicitly deferred in `SUN_INTERACTION_AND_LEGIBILITY_DOCTRINE.md`
pending the composition/WHAT authority. It has never shipped to an athlete.

**Why it doesn't sit right, concretely:** unequal wedges on one circle read as a chart you have to
parse (which slice is bigger, why), not a coordinate you glance at — the opposite of what FORM's
own "coordinate vs. score" law wants (`form-legibility-and-dial-doctrine`: *"a coordinate locates
you; a score evaluates you"*). And the four labels orbiting the circle at different angles fight
the "nothing crowded" standard you named in this exact request.

**The thing I'd actually flag as the real problem, though:** FORM already draws "the four
movements" a *second*, completely unrelated way. `FORMMovementMark.swift` — shipped, tested, used
on the chapter-close row and the Record seal — represents Start/Settle/Hold/Finish as struck
strokes inside a registration frame, with real authored geometry per movement (Start = rays
widening from a point; Settle = even parallel lines; Hold = compressing, shortening lines; Finish =
converging lines) and a real law (*"ornament must be evidence of belonging"* — a mark with nothing
struck must read as empty, strokes floor rather than round up). That system is better than the
ring in almost every way that matters here: it's already been through the discipline this pass is
chasing, it's legible in isolation, and it already has a defined small size (`inline`, 40pt) that
works inline in running text.

**My recommendation: don't redesign the ring. Delete it, and let the mark system say the same
thing everywhere the four movements appear — including wherever the ring was going to live.** One
visual vocabulary for one concept, not two. `mockups/continuity_pass_01.html` §1 shows this next to
two other honest options (a quieted single-ring, and a plain coordinate list) so you can see the
comparison rather than take my word for it. I built option B first as the recommendation, not
because it's the most decorated — it's the one that *removes* a design system instead of adding
one, which is the kind of correction that reads as expensive precisely because nobody can point at
what changed.

---

## 4. The Week Print

Codex's idea #5, kept, because it's the one place "make finishing work change the picture" can be
true without inventing a reward mechanic. Not an analytics recap — an archival object assembled
from what the week actually produced: the seven-day signature (this already exists, unshipped, in
`docs/design/week-close/` — width = extent, height = demand, rest sits on the baseline as an open
coordinate, not a void), the race countdown, one earned sentence *if* Read has one this week
(silence is correct most weeks — `form-silence-over-filler-voice-law` is non-negotiable here), and
nothing invented. Twelve weeks into a campaign, an athlete has twelve of these. That's affection
built from evidence, which is the only kind FORM's own doctrine allows it to manufacture.

Mockup in §3 of `continuity_pass_01.html`. It borrows the plate-and-record ruling's own language
("the dose, decomposed... paces on the plate, receding") for the card's internal hierarchy, so it
doesn't introduce a third typographic system.

---

## 5. Motion — a grammar, not a mood

Codex's "30–90 seconds, 2–6px, you should ask *was that there before?*" is the right instinct and
FORM doesn't currently have a written motion law that's this specific — `FORM_MOTION_DOCTRINE.md`
exists but is thinner than this. I'd propose adopting the specific numbers as a real constraint,
with FORM's own vocabulary attached to each:

- **Filing a session** leaves a trace, once — the Week Print's field-line lengthens by exactly the
  distance that session added. Not a progress bar (progress bars imply a target and a countable
  finish; FORM's own law is that completion is fulfillment of authored purpose, not a percentage
  — `form-frequency-ordinariness-doctrine`). A single mark strike, silent, the same discipline
  already ratified for week-close (*"day filing is a mark strike... once every seven days, cream,
  no charcoal"*).
- **Selecting a day** gets the faintest parallax already described in the deferred dial-scrub spec
  (`form-legibility-and-dial-doctrine`) — 2–4° of lag on the inner calibration ring, nothing more.
  That spec already exists and is arguably better-considered than anything Codex proposed; it's
  just never been built. Worth doing before anything new.
- **Chapter close** is the one place allowed to be *slow* — numeral, then spine, then name, then
  body, on the order of several seconds, exactly because it happens four times in six months. A
  weekly version of that pacing would read as an ad for FORM's own app (the file's own comment says
  this, verbatim — nobody has to invent this rule, it's already written).
- **Everything else stays still.** No idle-state animation, no breathing chrome, no parallax on
  ordinary navigation. The existing quiet-day "breath" (one slow expanding ring on a Rest day,
  already shipped) is close to the ceiling of how much motion Today should ever carry outside a
  filing or a chapter event.

The test for any new motion, borrowed directly from Codex but made falsifiable: **if you can name
what animated, cut it.** The three exceptions above (filing trace, dial-scrub lag, chapter pacing)
are the entire list. Nothing else gets a new animation without a reason that reads as strong as
those three.

---

## 6. What NOT to touch — the guardrails this whole pass has to respect

Because this is exactly the kind of session where good taste can accidentally undo settled work,
here's what's locked and why, so nothing downstream "improves" something that was already fought
for:

- **The Sun's interior six-register typography is LOCKED** (`form-interior-typography-lock`).
  Atmosphere, seasons, motion — none of it touches what's inside the plate. It surrounds the
  instrument; it never becomes the instrument.
- **The paper material (70/30 grain under Today) is shipped and done** (`form-paper-material-pass`)
  — and its exclusion list (linen, marble, stains, ornament, decorative metadata) is the actual
  legal boundary for how far "atmosphere" is allowed to go on the Sun specifically. Chapter close,
  Field, and the Week Print are outside that boundary; Today is not.
- **No legend, ever, for the structure-grammar marks** — this is a repeated, explicit rule
  (`docs/design/structure-grammar/README.md`: *"a legend is a confession that the mark failed to
  teach itself"*). If the ring becomes marks, the marks still can't get a key.
- **Silence over filler, always** (`form-silence-over-filler-voice-law`). The Week Print's one
  sentence, the chapter body, any new atmospheric copy — all of it has to pass the out-loud-coach
  test or render nothing. This is the law most likely to get quietly violated by anyone excited
  about "voice," including me, so I'm flagging it against myself too.
- **Ochre means exactly one thing per composition, never danger/warning** — already law, already
  correctly followed in the ring's "building" arc; keep it that way in whatever replaces the ring.
- **No incentive metrics, no live counters that exist to make a number rise**
  (`form-legibility-and-dial-doctrine`). This is the law the dragon idea would have quietly broken
  if adopted without the calendar-truth correction in §2.

---

## 7. The flow, start to close — where the actual seams are

You asked for the whole arc: placard → plan → onboarding → the first weeks → chapter close →
record. Here's the honest map of where it's continuous and where it currently isn't, from reading
the code, not the docs:

1. **Placard** (`FORMMovementPlacardView.swift`) — live, shipped, single canonical view. Fine as-is
   structurally; the charcoal-reverse material it uses is the same one the (currently unwired)
   chapter close and ring use, which is actually a nice existing thread to pull on if atmosphere
   ever needs a "these are the serious moments" material signature.
2. **Onboarding** — this is the seam most likely to confuse a design pass, because **three
   implementations currently exist in the tree**: `FORMOnboardingFlow.swift`, an older
   `FORMStrangerOnboardingFlow.swift`, and the current direction, `FORMFirstRunFlow.swift`, whose
   own authority doc states the intent plainly: *"we are not replacing ugly onboarding with pretty
   onboarding. We are deleting 'onboarding' as a separate product concept."* Any brainstorm work
   here should assume `FORMFirstRunFlow` is the live one and the other two are archaeology, not
   alternatives to reconcile.
3. **Plan** — live and shipping (`FORMPlanEditChrome`, `FORMWeekFieldCard`, `FORMWeekStrip`). A
   parallel, unmounted kit version (`FORMWeekFieldView`/`FORMWeekShapeView`) exists and is worth a
   side-by-side look, but isn't what an athlete sees today.
4. **The first weeks** — no literal "28-day" cycle exists in the programming brain (I want to
   correct my own assumption here, not just repeat yours): a Half campaign's chapters bind roughly
   every 6–7 weeks, four times across 26 weeks. The "28" in the docs refers to a separate
   Day-0-to-Day-28 *shipping-reachability audit window* (an internal QA framing), not a designed
   athlete-facing cycle. Worth naming precisely so we're not chasing a cadence that isn't real —
   the actual rare-event cadence (4x/campaign) is what the chapter close and any Week Print series
   should key off.
5. **Chapter close** — designed, authored, finished, unwired. See §1. This is the single highest-
   leverage item in this whole brief: it's not a design problem, it's a wiring problem, and the
   content is already better than most things I've read as "shipped" doctrine.
6. **Record** — two parallel systems exist: legacy Ledger record rooms (flagged legacy in the
   team's own reachability audit) and the current path, `FORMFiledRecordIndexView` →
   `FORMFiledReceiptView`, reached from the Placard's RECORD door. Design work should target the
   current path only.
7. **Filing / Read** — same pattern: the kit has an unmounted `FORMLogFaceView` that isn't what
   ships. The *live* filing surface is `FORMLogSheet.swift`/`FORMLogInstruments.swift` in
   `FORM/Ledger/`, and it's explicitly flagged as grammar-incomplete (palette/mono/pill sweep still
   owed) — this is probably the single most "unfinished-looking" surface an athlete actually
   touches today, more than the rings, because it's the one that's live but visibly not done. If
   this brainstorm produces one piece of near-term build work instead of long-range vision, my
   vote is this file, not the ring.

---

## 8. What's in this package

- `BRIEF.md` — this document.
- `mockups/continuity_pass_01.html` — the three-part visual brief: rings (three options + my
  call), chapter close (real authored copy, staged the way the rarity law demands), and the World
  + Week Print (with a live motion demo of the "trace, not a progress bar" idea from §5). Open it
  in an actual browser, not a text editor.
- `mockups/existing-prototypes/` — eight HTML prototypes your team already built and ratified
  (`the-plan`, `plate-and-record`, `week-close`, `weak-surfaces`, `structure-grammar` ×2,
  `filing_family`) — these are real prior work, not references I'm inventing continuity with.
  Several of the ideas above (the Week Print's field-line, the mark-registration frame) are direct
  extensions of what's already sitting in these files.
- `docs/` — the ~47 living design/doctrine documents this brief draws from (canon glass locks,
  evidence law, the design decision register, the filing/first-run/plate authorities, motion and
  voice doctrine). No Forge material, no dated ship-close snapshots — just what's actually still
  governing.
- `source/` — ~54 Swift files: every surface named in your request (placard, plan, onboarding,
  record, filing/read, the ring, the chapter close, the block-close passage, the movement mark) so
  whoever picks this up next doesn't have to re-find them.
- `memory/` — the 25 standing-law memory files this brief is accountable to, exported so the
  package is self-contained without needing my session history.

---

## 9. My close, as the partner who'd stand behind this in a review

If I'm honest about "premium enough for an award panel": the panel isn't going to notice a dragon.
They notice when an app has clearly made a hundred small refusals — the thing it *didn't* add, the
animation it *didn't* play, the metric it *didn't* show. FORM's actual competitive advantage, on
the evidence in this repo, is that it has already made more of those refusals than almost anything
I've read doctrine for. The chapter close sitting dead in a debug rail is the clearest waste in the
whole system: you already wrote the expensive thing. My honest recommendation, in order, is wire
it, unify the movement mark, then decide if the Week Print earns a slot — and treat the dragon as a
correct instinct pointed at the wrong object, not a plan.

— Claude
